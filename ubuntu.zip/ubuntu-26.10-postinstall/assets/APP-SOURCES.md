# Application choices

Run `1-first`, reboot into GNOME, run `2-after-reboot-into-gnome`, log out
and back in, then run `3-last`. In Files, right-click each numbered file and
choose **Run as a Program**. Keep the assets folder next to those files.

The app list is `assets/apps.tsv`. Delete a row to skip that app. Keep at
least one of the two browsers if you want the script to remove Snap.

## Native applications

These use their developer's DEB or signed APT repository:

| Application | Source and updates |
| --- | --- |
| Opera GX | [Opera GX APT repository](https://deb.opera.com/manual-gx.html) |
| Vivaldi | [Official DEB](https://vivaldi.com/download/), which configures its APT update repository |
| Steam | [Valve APT repository](https://repo.steampowered.com/steam/); Steam also updates its client itself |
| ONLYOFFICE | [Official APT repository](https://helpcenter.onlyoffice.com/desktop/installation/desktop-install-ubuntu.aspx) |
| Spotify | [Official APT repository](https://www.spotify.com/us/download/linux/) |
| Discord | [Official DEB](https://discord.com/download); Linux gained [automatic updates in May 2026](https://discord.com/blog/discord-patch-notes-may-4-2026) |
| GitHub Desktop | [Community Linux fork](https://github.com/shiftkey/desktop), using its documented mwt.me APT mirror; GitHub itself does not supply this Linux build |
| ChatGPT | [Official OpenAI Linux preview](https://learn.chatgpt.com/docs/linux/linux-app), using its DEB and package-managed updates |

Steam gets 32-bit and 64-bit OpenGL/Vulkan libraries and the 32-bit NVIDIA
library matching the installed driver. This avoids Flatpak filesystem
restrictions around games, mods and external launchers.

OpenAI currently lists Ubuntu 24.04 and 26.04 for ChatGPT, **not 26.10**.
The script installs the official package, but a successful install cannot
guarantee that the application launches on this release. Open it and sign in
after rebooting. If it does not work, use [ChatGPT in the browser](https://chatgpt.com/)
while waiting for upstream support; no unofficial wrapper is installed.

VS Code retains Microsoft's APT repository. CurseForge retains its vendor
DEB. Epic retains its official Linux preview AppImage. These existing
installers are separate from the editable app manifest.

## Prefer native when current

Celluloid, Inkscape, Krita, Blender and OBS compare the available APT version
with Flathub's stable application version at installation time. APT wins if
it is the same version or newer. A newer Flatpak wins otherwise. Unknown or
unparseable versions also use Flatpak, with the selected format recorded in
the installation log. Package revision numbers do not count as newer app
releases.

For [OBS](https://obsproject.com/kb/linux-installation), the script first
checks whether the official PPA publishes packages for the running Ubuntu
codename. If it does, those packages participate in the comparison. If it
does not, the script compares Ubuntu's package with the official Flatpak.
It never substitutes a PPA for a different Ubuntu release. The OBS PPA did
not publish Ubuntu 26.10 when this was checked on 23 October 2026.

Celluloid replaces the separate mpv and MPC-QT app entries. Celluloid itself
uses the mpv playback library, so seeing `libmpv` among its dependencies is
normal.

On reruns, these automatically selected apps keep their existing format to
preserve profiles and projects. Existing Flatpak installations of apps now
set to native are not deleted: install the native app, move any needed data,
then remove the unwanted duplicate through GNOME Software. The script does
not delete application data or uninstall an existing mpv/MPC-QT installation.

## Flatpak choices

* [Prism Launcher](https://prismlauncher.org/download/linux/),
  [Modrinth](https://modrinth.com/app) and
  [Extension Manager](https://github.com/mjakeman/extension-manager): upstream
  recommends this distribution method.
* [GIMP](https://www.gimp.org/downloads/): official managed Linux build.
* [GPU Screen Recorder](https://git.dec05eba.com/gpu-screen-recorder/about/):
  packaged GUI without building from source on Ubuntu.
* [Stremio](https://www.stremio.com/downloads): upstream Linux Universal build.
* Flatseal: manages permissions for the remaining Flatpak apps.

GNOME Software handles both APT and Flatpak updates. After changing NVIDIA
drivers and rebooting, update Flatpaks so their NVIDIA runtime matches.
The second stage does this automatically. Test recording in OBS and GPU
Screen Recorder and approve GNOME's screen-sharing dialog when prompted.

Source decisions checked on 23 October 2026. Downloads and repository
metadata can change; failures are logged and independent app installs
continue. A real Ubuntu 26.10 desktop test is still required.
