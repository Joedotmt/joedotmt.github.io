#!/usr/bin/env bash
# Shared terminal launcher. The three scripts in the parent folder call this.
set -uo pipefail
ASSET_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd) || exit 2
IN_TERMINAL=0
if [[ ${1:-} == --in-terminal ]]; then
    IN_TERMINAL=1
    shift
fi
STAGE=${1:-}
(( $# )) && shift
case "$STAGE" in
    system) TITLE='First — system setup' ;;
    desktop) TITLE='After reboot into GNOME — desktop setup' ;;
    verify) TITLE='Last — verification' ;;
    *) echo 'Unknown setup stage.' >&2; exit 2 ;;
esac
if (( $# > 1 )) || { (( $# == 1 )) && [[ $1 != --dry-run ]]; }; then
    echo 'The only optional argument is --dry-run.' >&2
    exit 2
fi

# A real terminal is needed for sudo prompts and to keep the results visible.
if (( ! IN_TERMINAL )) && { [[ ! -t 0 ]] || [[ ! -t 1 ]]; }; then
    if command -v ptyxis >/dev/null 2>&1; then
        exec ptyxis --new-window --title="$TITLE" -- \
            /bin/bash "$ASSET_DIR/launch-stage.sh" --in-terminal "$STAGE" "$@"
    elif command -v gnome-terminal >/dev/null 2>&1; then
        exec gnome-terminal --wait --title="$TITLE" -- \
            /bin/bash "$ASSET_DIR/launch-stage.sh" --in-terminal "$STAGE" "$@"
    elif command -v x-terminal-emulator >/dev/null 2>&1; then
        exec x-terminal-emulator -e \
            /bin/bash "$ASSET_DIR/launch-stage.sh" --in-terminal "$STAGE" "$@"
    else
        message='No supported terminal was found. Open a terminal in this folder and run the script there.'
        printf '%s\n' "$message" >&2
        if command -v zenity >/dev/null 2>&1; then
            zenity --error --title='Ubuntu setup' --text="$message" || true
        fi
        exit 2
    fi
fi

printf '\n%s\n\n' "$TITLE"
case "$STAGE" in
    system) echo 'This installs the system, drivers and selected applications. Enter your login password when sudo asks.' ;;
    desktop) echo 'Run this after rebooting and choosing GNOME at the login screen.' ;;
    verify) echo 'Run this after logging out and back into GNOME following desktop setup.' ;;
esac
printf '\n'

/bin/bash "$ASSET_DIR/post-install.sh" "$STAGE" "$@"
RESULT=$?
printf '\n'
if (( RESULT == 0 )); then
    if [[ ${1:-} == --dry-run ]]; then
        echo 'Preview complete. No setup changes were made.'
    else
        case "$STAGE" in
            system) echo 'Next: reboot, choose GNOME at login, then run 2-after-reboot-into-gnome.' ;;
            desktop) echo 'Next: log out and back into GNOME, then run 3-last.' ;;
            verify) echo 'Checks finished. Read the manual checks in the error log printed above.' ;;
        esac
    fi
else
    printf 'This stage needs attention (exit %s). Read the messages above before continuing.\n' "$RESULT"
    echo 'If a log path was printed, review that log, fix the problem, and run this stage again.'
fi
if [[ -t 0 ]]; then
    printf '\nPress Enter to close this stage… '
    IFS= read -r _ || true
fi
exit "$RESULT"
