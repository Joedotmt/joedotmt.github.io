#!/usr/bin/env python3
"""Per-user GNOME setup. Called by post-install.sh, never with sudo."""
import argparse
import ast
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
USER_EXT = Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local/share"))) / "gnome-shell/extensions"
SYSTEM_EXT = Path("/usr/share/gnome-shell/extensions")
FAILURES = []


class ExtensionUnavailable(RuntimeError):
    """A release/dependency compatibility skip, not an installation failure."""


def warn(message):
    text = "[WARNING] " + message + "\n"
    print(text, flush=True)
    log = os.environ.get("POSTINSTALL_ERROR_LOG")
    if log:
        with open(log, "a") as f:
            f.write(text)


def fail(message):
    FAILURES.append(message)
    text = "[ACTION REQUIRED] " + message + "\n"
    print(text, flush=True)
    log = os.environ.get("POSTINSTALL_ERROR_LOG")
    if log:
        with open(log, "a") as f:
            f.write(text)


def command(*args):
    p = subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode:
        raise RuntimeError(f"{' '.join(map(str, args))}: {p.stderr.strip() or p.stdout.strip()}")
    return p.stdout.strip()


def require_session():
    if os.geteuid() == 0:
        raise RuntimeError("Run as the desktop user, WITHOUT sudo.")
    desktop = os.environ.get("XDG_CURRENT_DESKTOP", "")
    if "GNOME" not in desktop.upper() or not os.environ.get("DBUS_SESSION_BUS_ADDRESS"):
        raise RuntimeError("Run from a terminal in a logged-in GNOME desktop, not SSH/TTY/root.")
    if "ubuntu" in desktop.lower():
        raise RuntimeError('Log out; select your user, then the gear menu > GNOME. This is still the Ubuntu session.')
    match = re.search(r"\b(\d+)(?:\.\d+)*", command("gnome-shell", "--version"))
    if not match or match.group(1) != "51":
        raise RuntimeError("Expected GNOME Shell 51. Check gnome-shell --version.")
    return "51"


def compatible(metadata, major):
    return major in [str(v) for v in metadata.get("shell-version", [])]


def read_metadata(path):
    return json.loads((path / "metadata.json").read_text())


def fetch(url, limit=32 * 1024 * 1024):
    # Standard TLS validation, bounded downloads, retries for transient failures.
    class HTTPSRedirects(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            if urllib.parse.urlparse(newurl).scheme != "https":
                raise RuntimeError("Refusing a non-HTTPS redirect")
            return super().redirect_request(req, fp, code, msg, headers, newurl)

    opener = urllib.request.build_opener(HTTPSRedirects())
    last = None
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "UbuntuPostInstall/1.0"})
            with opener.open(req, timeout=45) as response:
                if urllib.parse.urlparse(response.url).scheme != "https":
                    raise RuntimeError("Refusing a non-HTTPS redirect")
                data = response.read(limit + 1)
                if len(data) > limit:
                    raise RuntimeError("Download exceeded size limit")
                return data
        except Exception as exc:
            last = exc
            if attempt < 2:
                time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"Download failed: {url}: {last}")


def choose_release(info, major):
    release = info.get("shell_version_map", {}).get(major)
    if release is None:
        raise ExtensionUnavailable(f"No approved release declares GNOME {major} support. Retry desktop later or check Extension Manager.")
    if not isinstance(release, dict) or not isinstance(release.get("pk"), int) or release["pk"] <= 0:
        raise RuntimeError("Malformed release information returned by extensions.gnome.org")
    return release


def check_dependencies(entry, installed):
    by_id = {str(e["id"]): e for e in installed if e.get("status") == "installed"}
    missing = [str(d) for d in entry.get("requires", []) if str(d) not in by_id]
    if missing:
        raise RuntimeError(f"Required extension(s) did not install: {', '.join(missing)}. Fix those first and rerun desktop.")
    for dependency, wanted in entry.get("requires_versions", {}).items():
        target = by_id[str(dependency)]
        metadata = read_metadata(Path(target["path"]))
        if metadata.get("uuid") != target["uuid"]:
            raise RuntimeError(f"Dependency identity mismatch: {target['name']}")
        if metadata.get("version") != wanted:
            raise ExtensionUnavailable(
                f"Requires tested {target['name']} extension version {wanted}; found {metadata.get('version')}. "
                "The companion must stay disabled until it is tested with this release.")


def safe_extract(data, destination, uuid, major):
    """Reject traversal, symlinks, special files and oversized ZIP members."""
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        members = archive.infolist()
        if len(members) > 5000 or sum(m.file_size for m in members) > 128 * 1024 * 1024:
            raise RuntimeError("Extension archive exceeds extraction limits")
        seen = set()
        for member in members:
            path = PurePosixPath(member.filename)
            mode = member.external_attr >> 16
            if (path.is_absolute() or ".." in path.parts or "\\" in member.filename
                    or member.filename in seen or not path.parts):
                raise RuntimeError("Unsafe or duplicate extension archive path")
            seen.add(member.filename)
            if stat.S_ISLNK(mode) or stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR):
                raise RuntimeError("Links/special files are not accepted in an extension archive")
        metadata = json.loads(archive.read("metadata.json"))
        if metadata.get("uuid") != uuid or not compatible(metadata, major):
            raise RuntimeError("Archive UUID or GNOME compatibility does not match the requested extension")
        for member in members:
            target = destination.joinpath(*PurePosixPath(member.filename).parts)
            if member.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(member))
                target.chmod(0o755 if (member.external_attr >> 16) & 0o111 else 0o644)
    return metadata


def move_as_backup(path, backup):
    if path.exists() or path.is_symlink():
        if path.is_symlink():
            raise RuntimeError(f"Refusing to replace symlink: {path}")
        target = backup / "extensions" / path.name
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            target = target.with_name(target.name + "-" + str(time.time_ns()))
        shutil.move(str(path), str(target))
        return target
    return None


def use_system(entry, major, backup):
    uuid = entry.get("system_uuid")
    if not uuid:
        return None
    path = SYSTEM_EXT / uuid
    try:
        metadata = read_metadata(path)
    except (OSError, ValueError):
        return None
    if metadata.get("uuid") != uuid or not compatible(metadata, major):
        return None
    # User copies override distro copies. Preserve and remove an incompatible override.
    user_path = USER_EXT / uuid
    if user_path.exists():
        try:
            if compatible(read_metadata(user_path), major):
                return {**entry, "uuid": uuid, "path": str(user_path), "status": "installed"}
        except (OSError, ValueError):
            pass
        move_as_backup(user_path, backup)
    print(f"Using compatible Ubuntu extension: {entry['name']}")
    return {**entry, "uuid": uuid, "path": str(path), "status": "installed"}


def install_extension(entry, major, backup):
    if entry.get("archive"):
        return install_bundled_extension(entry, major, backup)
    existing = use_system(entry, major, backup)
    if existing:
        return existing
    query = urllib.parse.urlencode({"pk": entry["id"], "shell_version": major})
    info = json.loads(fetch("https://extensions.gnome.org/extension-info/?" + query, 2 * 1024 * 1024))
    uuid = info.get("uuid", "")
    if info.get("pk") != entry["id"] or not re.fullmatch(r"[A-Za-z0-9_+@.-]+", uuid) or uuid.startswith("."):
        raise RuntimeError("Invalid extension identity returned by extensions.gnome.org")
    release = choose_release(info, major)
    path = USER_EXT / uuid
    if path.exists() and not path.is_symlink():
        try:
            metadata = read_metadata(path)
        except (OSError, ValueError):
            metadata = {}  # Repair a damaged user copy, preserving it in the backup.
        if (metadata.get("uuid") == uuid and compatible(metadata, major)
                and metadata.get("version") == release.get("version")):
            print(f"Already installed: {entry['name']}")
            return {**entry, "uuid": uuid, "path": str(path), "status": "installed"}
    url = ("https://extensions.gnome.org/download-extension/" + urllib.parse.quote(uuid, safe="")
           + ".shell-extension.zip?" + urllib.parse.urlencode({"version_tag": release["pk"]}))
    data = fetch(url)
    USER_EXT.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".postinstall-", dir=USER_EXT) as tmp:
        unpacked = Path(tmp) / "extension"
        unpacked.mkdir()
        metadata = safe_extract(data, unpacked, uuid, major)
        if (unpacked / "schemas").is_dir():
            command("glib-compile-schemas", str(unpacked / "schemas"))
        old = move_as_backup(path, backup)
        try:
            unpacked.rename(path)
        except Exception:
            if old:
                shutil.move(str(old), str(path))
            raise
    print(f"Installed {entry['name']} ({uuid}), release {metadata.get('version')}")
    return {**entry, "uuid": uuid, "path": str(path), "status": "installed"}


def bundled_asset(relative):
    path = (ROOT / relative).resolve()
    if not path.is_relative_to(ROOT.resolve()) or not path.is_file():
        raise RuntimeError(f"Missing/invalid bundled file: {relative}. Copy the entire post-install folder, including subfolders.")
    return path


def bundled_archive(entry):
    data = bundled_asset(entry["archive"]).read_bytes()
    if hashlib.sha256(data).hexdigest() != entry.get("sha256"):
        raise RuntimeError(f"Checksum mismatch for {entry['archive']}; restore the original bundled ZIP.")
    return data


def install_bundled_extension(entry, major, backup):
    uuid = entry.get("uuid", "")
    if not re.fullmatch(r"[A-Za-z0-9_+@.-]+", uuid) or uuid.startswith("."):
        raise RuntimeError("Invalid bundled extension UUID")
    data = bundled_archive(entry)
    USER_EXT.mkdir(parents=True, exist_ok=True)
    path = USER_EXT / uuid
    with tempfile.TemporaryDirectory(prefix=".postinstall-", dir=USER_EXT) as tmp:
        unpacked = Path(tmp) / "extension"
        unpacked.mkdir()
        metadata = safe_extract(data, unpacked, uuid, major)
        if (unpacked / "schemas").is_dir():
            command("glib-compile-schemas", str(unpacked / "schemas"))
        old = move_as_backup(path, backup)
        try:
            unpacked.rename(path)
        except Exception:
            if old:
                shutil.move(str(old), str(path))
            raise
    print(f"Installed bundled {entry['name']} ({uuid}), release {metadata.get('version')}")
    return {**entry, "path": str(path), "status": "installed"}


def verify_bundled_extension(entry):
    """Check source files against the pinned ZIP, excluding regenerated schemas."""
    with zipfile.ZipFile(io.BytesIO(bundled_archive(entry))) as archive:
        for member in archive.infolist():
            if member.is_dir() or member.filename.endswith("gschemas.compiled"):
                continue
            relative = PurePosixPath(member.filename)
            if relative.is_absolute() or ".." in relative.parts:
                raise RuntimeError("Unsafe bundled extension path")
            path = Path(entry["path"]).joinpath(*relative.parts)
            if not path.is_file() or path.read_bytes() != archive.read(member):
                raise RuntimeError(f"Installed bundled file differs: {member.filename}. Rerun desktop to restore the packaged copy.")


def configure_saved_settings(entry, verify_only=False):
    """Apply/verify all effective AATWS values, including defaults and Alt-Tab keys."""
    from gi.repository import Gio, GLib

    snapshot = json.loads(bundled_asset(entry["settings"]).read_text())
    if snapshot.get("format") != 1:
        raise RuntimeError("Unsupported saved-settings format")
    metadata = read_metadata(Path(entry["path"]))
    source = snapshot.get("source", {})
    if metadata.get("uuid") != source.get("extension_uuid") or metadata.get("version") != source.get("extension_version"):
        raise RuntimeError("AATWS version differs from the saved settings. Restore the bundled version before importing.")
    default_source = Gio.SettingsSchemaSource.get_default()
    schema_source = Gio.SettingsSchemaSource.new_from_directory(str(Path(entry["path"]) / "schemas"), default_source, False)
    total = 0
    for group in snapshot["schemas"]:
        # Only AATWS and the six explicitly captured switcher bindings belong here.
        schema_id = group["id"]
        if schema_id not in {"org.gnome.shell.extensions.advanced-alt-tab-window-switcher", "org.gnome.desktop.wm.keybindings"}:
            raise RuntimeError(f"Unexpected schema in AATWS snapshot: {schema_id}")
        schema = schema_source.lookup(schema_id, True)
        if schema is None:
            fail(f"AATWS snapshot: target schema is missing: {schema_id}")
            continue
        settings = Gio.Settings.new_full(schema, None, None)
        pending = []
        for key, saved in group["values"].items():
            try:
                if schema_id == "org.gnome.desktop.wm.keybindings" and key not in {
                    "switch-applications", "switch-applications-backward", "switch-windows",
                    "switch-windows-backward", "switch-group", "switch-group-backward"
                }:
                    raise RuntimeError("key is outside the six saved switcher shortcuts")
                if not schema.has_key(key):
                    raise RuntimeError("key is not available on this PC")
                schema_key = schema.get_key(key)
                value_type = schema_key.get_value_type()
                if value_type.dup_string() != saved["type"]:
                    raise RuntimeError("saved value has a different type from the installed schema")
                wanted = GLib.Variant.parse(value_type, saved["value"], None, None)
                if not schema_key.range_check(wanted):
                    raise RuntimeError("saved value is outside the installed schema's allowed range")
                if not verify_only:
                    if not settings.is_writable(key) or not settings.set_value(key, wanted):
                        raise RuntimeError("setting is locked or could not be written")
                pending.append((key, wanted))
            except Exception as exc:
                fail(f"AATWS saved setting {schema_id} {key}: {exc}")
        if not verify_only:
            Gio.Settings.sync()
        for key, wanted in pending:
            actual = settings.get_value(key)
            if not actual.equal(wanted):
                fail(f"AATWS saved setting {schema_id} {key}: expected {wanted.print_(True)}, found {actual.print_(True)}. Rerun desktop, then log out/in.")
            else:
                total += 1
    print(f"{'Verified' if verify_only else 'Restored'} {total} saved AATWS/shortcut settings.")


def decode_variant(text):
    text = re.sub(r"^@[a-z]+\s+", "", text)
    if text == "true":
        return True
    if text == "false":
        return False
    return ast.literal_eval(text)


def get_setting(schema, key, schema_dir=None):
    args = ["gsettings"]
    if schema_dir:
        args += ["--schemadir", str(schema_dir)]
    return decode_variant(command(*args, "get", schema, key))


def set_setting(schema, key, value, schema_dir=None):
    args = ["gsettings"]
    if schema_dir:
        args += ["--schemadir", str(schema_dir)]
    if command(*args, "writable", schema, key) != "true":
        raise RuntimeError(f"{schema} {key} is locked by system policy")
    literal = ("true" if value else "false") if isinstance(value, bool) else repr(value)
    command(*args, "set", schema, key, literal)
    actual = get_setting(schema, key, schema_dir)
    if actual != value:
        raise RuntimeError(f"{schema} {key} did not persist: expected {value!r}, found {actual!r}")
    print(f"Set {schema} {key} = {actual!r}")


def arc_layout(schema_dir):
    """Find Windows 11's schema value, supporting enums and newer string choices."""
    docs = [ET.parse(path).getroot() for path in schema_dir.glob("*.gschema.xml")]
    for doc in docs:
        for schema in doc.findall("schema"):
            if schema.get("id") != "org.gnome.shell.extensions.arcmenu":
                continue
            key = schema.find("key[@name='menu-layout']")
            if key is None:
                continue
            choices = [c.get("value") for c in key.findall("choices/choice")]
            enum_id = key.get("enum")
            if enum_id:
                for other in docs:
                    for enum in other.findall("enum"):
                        if enum.get("id") == enum_id:
                            choices.extend(v.get("nick") for v in enum.findall("value"))
            for value in choices:
                if value and re.sub(r"[^a-z0-9]", "", value.lower()) in {"11", "eleven", "windows11"}:
                    return value
    raise RuntimeError('Cannot identify ArcMenu Windows 11 layout in its installed schema. Choose "11"/"Eleven" manually in ArcMenu preferences.')


BASE_SETTINGS = [
    ("org.gnome.desktop.interface", "color-scheme", "prefer-dark"),
    ("org.gnome.desktop.interface", "gtk-theme", "Adwaita-dark"),
    ("org.gnome.desktop.wm.preferences", "button-layout", ":minimize,maximize,close"),
]


def setup(major, backup, state):
    backup.mkdir(parents=True, exist_ok=True)
    # Stop before making changes if settings could not be preserved.
    dump = command("dconf", "dump", "/org/gnome/")
    (backup / "gnome-settings.dconf").write_text(dump + "\n")
    for schema, key, value in BASE_SETTINGS:
        try:
            set_setting(schema, key, value)
        except Exception as exc:
            fail(str(exc))
    results = []
    for entry in json.loads((ROOT / "extensions.json").read_text()):
        print(f"\nChecking {entry['name']} for GNOME {major}...", flush=True)
        try:
            check_dependencies(entry, results)
            results.append(install_extension(entry, major, backup))
        except Exception as exc:
            origin = entry.get("archive") or f"https://extensions.gnome.org/extension/{entry['id']}/"
            skipped = entry.get("optional", False) and isinstance(exc, ExtensionUnavailable)
            (warn if skipped else fail)(f"{entry['name']}: {exc} Source: {origin}")
            results.append({**entry, "status": "skipped" if skipped else "failed", "error": str(exc)})
    state.write_text(json.dumps({"shell": major, "extensions": results}, indent=2) + "\n")
    good = {e["id"]: e for e in results if e["status"] == "installed"}
    # Import before enabling AATWS so its first activation uses the saved behaviour.
    for entry in good.values():
        if entry.get("settings"):
            try:
                configure_saved_settings(entry)
            except Exception as exc:
                fail(f"{entry['name']} saved settings: {exc}")
    try:
        enabled = get_setting("org.gnome.shell", "enabled-extensions")
        disabled = get_setting("org.gnome.shell", "disabled-extensions")
        desired = [e["uuid"] for e in good.values()]
        # A previously enabled companion must not survive a failed dependency check.
        blocked = [e["uuid"] for e in results
                   if e.get("requires_versions") and e["status"] != "installed"]
        enabled = [u for u in enabled if u not in blocked]
        disabled = list(dict.fromkeys(disabled + blocked))
        enabled = list(dict.fromkeys(enabled + desired))
        disabled = [u for u in disabled if u not in desired]
        if 1160 in good:
            enabled = [u for u in enabled if u != "ubuntu-dock@ubuntu.com"]
            if "ubuntu-dock@ubuntu.com" not in disabled:
                disabled.append("ubuntu-dock@ubuntu.com")
        set_setting("org.gnome.shell", "disabled-extensions", disabled)
        set_setting("org.gnome.shell", "enabled-extensions", enabled)
        set_setting("org.gnome.shell", "disable-user-extensions", False)
    except Exception as exc:
        fail(f"Could not enable extensions: {exc}")
    if 3628 in good:
        try:
            schema_dir = Path(good[3628]["path"]) / "schemas"
            set_setting("org.gnome.shell.extensions.arcmenu", "menu-layout", arc_layout(schema_dir), schema_dir)
        except Exception as exc:
            fail(f"ArcMenu layout: {exc}")
    if 1160 in good:
        try:
            schema_dir = Path(good[1160]["path"]) / "schemas"
            # Dash to Panel stores monitor positions as a JSON string, monitor 0 being primary.
            set_setting("org.gnome.shell.extensions.dash-to-panel", "panel-positions", '{"0":"BOTTOM"}', schema_dir)
        except Exception as exc:
            fail(f"Panel position: {exc}. Set the panel to Bottom in Dash to Panel preferences.")
    print("\nLog out and back into GNOME before running verify. Existing settings and replaced extensions were backed up.")


def verify(major, state):
    for schema, key, wanted in BASE_SETTINGS:
        try:
            actual = get_setting(schema, key)
            if actual != wanted:
                raise RuntimeError(f"expected {wanted!r}, found {actual!r}")
            print(f"PASS {key}")
        except Exception as exc:
            fail(f"Desktop setting {key}: {exc}. Rerun desktop.")
    if not state.exists():
        fail("No extension installation record found. Run desktop, log out/in, then verify.")
        return
    data = json.loads(state.read_text())
    manifest = {e["id"]: e for e in json.loads((ROOT / "extensions.json").read_text())}
    recorded_ids = {entry["id"] for entry in data.get("extensions", [])}
    for expected in manifest.values():
        if expected["id"] not in recorded_ids:
            fail(f"{expected['name']} is missing from the installation record. Run desktop with this updated pack, log out/in, then verify.")
    for entry in data.get("extensions", []):
        expected = manifest.get(entry["id"], entry)
        if entry.get("status") == "skipped" and expected.get("optional"):
            warn(f"{entry['name']} skipped: {entry.get('error', 'unavailable')}. Rerun desktop to retry.")
            continue
        if entry.get("status") != "installed":
            fail(f"{entry['name']} was not installed: {entry.get('error', 'unknown failure')}. Fix the recorded error and rerun desktop.")
            continue
        try:
            check_dependencies(expected, data.get("extensions", []))
            metadata = read_metadata(Path(entry["path"]))
            if not compatible(metadata, major):
                raise RuntimeError("Installed metadata no longer declares GNOME 51 compatibility")
            if entry.get("archive"):
                verify_bundled_extension(entry)
            info = command("gnome-extensions", "info", entry["uuid"])
            live = re.search(r"^\s*State:\s*(.+)$", info, re.MULTILINE)
            if not live or live.group(1).strip() not in {"ENABLED", "ACTIVE"}:
                raise RuntimeError(info)
            print(f"PASS live extension {entry['name']}")
        except Exception as exc:
            fail(f"{entry['name']}: {exc}. Log out/in first; inspect Extension Manager and journalctl --user -b for extension errors.")
        if entry.get("settings"):
            try:
                configure_saved_settings(entry, verify_only=True)
            except Exception as exc:
                fail(f"{entry['name']} saved-settings verification: {exc}")
    arc = next((e for e in data.get("extensions", []) if e["id"] == 3628 and e.get("status") == "installed"), None)
    if arc:
        try:
            directory = Path(arc["path"]) / "schemas"
            actual = get_setting("org.gnome.shell.extensions.arcmenu", "menu-layout", directory)
            if actual != arc_layout(directory):
                raise RuntimeError(f"Windows 11 layout not selected (found {actual!r})")
            print("PASS ArcMenu Windows 11 layout")
        except Exception as exc:
            fail(f"ArcMenu layout: {exc}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["setup", "verify"])
    parser.add_argument("--backup", type=Path, required=True)
    parser.add_argument("--state", type=Path, required=True)
    args = parser.parse_args()
    try:
        major = require_session()
        if args.mode == "setup":
            setup(major, args.backup, args.state)
        else:
            verify(major, args.state)
    except Exception as exc:
        fail(str(exc))
    return 1 if FAILURES else 0


if __name__ == "__main__":
    sys.exit(main())
