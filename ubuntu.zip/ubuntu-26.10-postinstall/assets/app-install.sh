#!/usr/bin/env bash
# Sourced by post-install.sh after run(), apt_step(), download() and logging exist.

app_selected_pkg() {
    awk -F '\t' -v package="$1" '$1 !~ /^#/ && $2 == package {found=1} END {exit !found}' "$SCRIPT_DIR/apps.tsv"
}

apt_candidate() {
    apt-cache policy "$1" 2>/dev/null | awk '/Candidate:/ {print $2; exit}'
}

app_repo() {
    local name=$1 key_url=$2 url=$3 suite=$4 components=$5 arch=${6:-amd64} format=${7:-armor}
    local key="$LOG_DIR/$name.key" keyring="$LOG_DIR/$name.gpg"
    local source="/etc/apt/sources.list.d/${8:-$1}.list" created=0
    # Packages may already have configured the same upstream feed themselves.
    if grep -rqsF "$url" /etc/apt/sources.list /etc/apt/sources.list.d 2>/dev/null; then
        return 0
    fi
    run "Download $name signing key" 'Retry this stage when the vendor repository is available.' \
        download "$key_url" "$key" || return
    run "Validate $name signing key" 'The repository key must be valid OpenPGP.' \
        gpg --batch --show-keys "$key" || return
    if [[ $format == binary ]]; then
        cp -- "$key" "$keyring" || { issue "Cannot stage $name keyring."; return 1; }
    else
        run "Convert $name signing key" 'Check the vendor signing key.' \
            gpg --batch --yes --dearmor --output "$keyring" "$key" || return
    fi
    run "Install scoped $name keyring" 'Check /usr/share/keyrings permissions.' \
        sudo -n install -m 0644 "$keyring" "/usr/share/keyrings/$name.gpg" || return
    printf 'deb [arch=%s signed-by=/usr/share/keyrings/%s.gpg] %s %s %s\n' \
        "$arch" "$name" "$url" "$suite" "$components" > "$LOG_DIR/$name.list" || return 1
    [[ -e $source ]] || created=1
    run "Add $name repository" 'Check /etc/apt/sources.list.d/.' \
        sudo -n install -m 0644 "$LOG_DIR/$name.list" "$source" || return
    if ! apt_step "Refresh $name repository" update; then
        if (( created )); then
            run "Remove unavailable $name source added by this run" 'Remove this source before retrying APT.' \
                sudo -n rm -f -- "$source"
        fi
        return 1
    fi
}

install_vendor_deb() {
    local name=$1 package=$2 url=$3 deb="$LOG_DIR/$2.deb" staged rc
    run "Download $name from its developer" 'Retry 1-first; see APP-SOURCES.md for official downloads.' \
        download "$url" "$deb" || return
    if [[ $(dpkg-deb -f "$deb" Package 2>/dev/null) != "$package" || \
          $(dpkg-deb -f "$deb" Architecture 2>/dev/null) != amd64 ]]; then
        issue "$name download is not the expected amd64 $package DEB; it was not installed."
        return 1
    fi
    sudo -v || { issue "Sudo authentication failed before installing $name."; return 1; }
    staged=$(sudo -n mktemp "/var/tmp/$package-postinstall-XXXXXX.deb") || {
        issue "Cannot stage $name installer."; return 1;
    }
    if run "Stage $name installer" 'Check free disk space.' sudo -n install -m 0644 "$deb" "$staged"; then
        apt_step "Install $name (native DEB)" install -y "$staged"
        rc=$?
    else
        rc=1
    fi
    run "Remove temporary $name installer" "Remove $staged manually if needed." sudo -n rm -f -- "$staged"
    return "$rc"
}

prepare_obs_source() {
    local VERSION_CODENAME=''
    # Never borrow a PPA built for another Ubuntu release.
    source /etc/os-release
    if [[ ! $VERSION_CODENAME =~ ^[a-z]+$ ]]; then
        issue 'Cannot identify the Ubuntu codename for OBS.'; return 1
    fi
    if curl --fail --silent --show-error --location --connect-timeout 10 --max-time 30 \
            --proto '=https' --proto-redir '=https' \
            "https://ppa.launchpadcontent.net/obsproject/obs-studio/ubuntu/dists/$VERSION_CODENAME/Release" \
            -o "$LOG_DIR/obs-ppa-release" 2>"$LOG_DIR/obs-ppa-probe.log"; then
        run 'Enable the official OBS PPA for this Ubuntu release' 'Check the official OBS installation instructions.' \
            sudo -n add-apt-repository -y ppa:obsproject/obs-studio || return
        apt_step 'Refresh OBS packages' update
    else
        note 'OBS PPA is unavailable for this Ubuntu release. Comparing Ubuntu OBS with the official Flatpak; no foreign-release PPA was added.'
    fi
}

prepare_app_source() {
    case "$1" in
        opera-gx-stable)
            app_repo opera-browser https://deb.opera.com/archive.key \
                https://deb.opera.com/opera-gx-stable/ stable non-free amd64 armor opera-archive ;;
        spotify-client)
            app_repo spotify https://download.spotify.com/debian/pubkey_5384CE82BA52C83A.asc \
                https://repository.spotify.com stable non-free ;;
        onlyoffice-desktopeditors)
            app_repo onlyoffice https://download.onlyoffice.com/GPG-KEY-ONLYOFFICE \
                https://download.onlyoffice.com/repo/debian squeeze main ;;
        github-desktop)
            app_repo mwt-desktop https://mirror.mwt.me/shiftkey-desktop/gpgkey \
                https://mirror.mwt.me/shiftkey-desktop/deb/ any main ;;
        steam-launcher)
            app_repo steam https://repo.steampowered.com/steam/steam.gpg \
                https://repo.steampowered.com/steam/ stable steam amd64,i386 binary ;;
        obs-studio) prepare_obs_source ;;
        *) return 0 ;;
    esac
}

install_steam_libraries() {
    apt_step 'Install Steam OpenGL/Vulkan libraries (64-bit and 32-bit)' install -y \
        libgl1:amd64 libgl1:i386 libgl1-mesa-dri:amd64 libgl1-mesa-dri:i386 \
        libvulkan1:amd64 libvulkan1:i386 mesa-vulkan-drivers:amd64 mesa-vulkan-drivers:i386 || return
    local package
    local -a nvidia_libraries=()
    # Match the driver actually installed, including the server branch if selected.
    mapfile -t nvidia_libraries < <(dpkg-query -W -f='${binary:Package}\t${db:Status-Status}\n' 'libnvidia-gl-*' 2>/dev/null |
        awk '$2 == "installed" && $1 ~ /^libnvidia-gl-[0-9]+(-server)?(:amd64)?$/ {sub(/:amd64$/, "", $1); print $1 ":i386"}')
    for package in "${nvidia_libraries[@]}"; do
        apt_step "Install Steam NVIDIA library $package" install -y "$package" || return
    done
}

install_native_app() {
    local package=$1 name=$2 url
    case "$package" in
        vivaldi-stable)
            run 'Read official Vivaldi downloads' 'Check https://vivaldi.com/download/.' \
                download https://vivaldi.com/download/ "$LOG_DIR/vivaldi-download.html" || return
            url=$(/usr/bin/python3 "$SCRIPT_DIR/app-metadata.py" vivaldi-url "$LOG_DIR/vivaldi-download.html") || {
                issue 'Could not resolve the official Vivaldi DEB download.'; return 1;
            }
            install_vendor_deb "$name" "$package" "$url" ;;
        discord)
            install_vendor_deb "$name" "$package" \
                'https://discord.com/api/download?format=deb&platform=linux' ;;
        chatgpt)
            install_vendor_deb "$name" "$package" \
                https://persistent.oaistatic.com/codex-app-prod/linux/deb/latest/chatgpt_amd64.deb || return
            note 'ChatGPT Linux preview installed. Open it and sign in. OpenAI currently lists Ubuntu 24.04/26.04 as supported; launch on 26.10 needs checking.' ;;
        steam-launcher)
            install_steam_libraries || return
            apt_step "Install $name (native APT)" install -y "$package" ;;
        *) apt_step "Install $name (native APT)" install -y "$package" ;;
    esac
}

cache_flatpak_versions() {
    flatpak remote-ls --system --app --arch=x86_64 \
        --columns=application:f,version:f,branch:f flathub > "$LOG_DIR/flathub-versions.tsv"
}

choose_app_format() {
    local policy=$1 package=$2 id=$3 native_version flat_version
    case "$policy" in
        native) echo native ;;
        flatpak) echo flatpak ;;
        auto)
            # Keep existing profiles/projects in their original format on reruns.
            if pkg_installed "$package"; then echo native; return; fi
            if flat_installed "$id"; then echo flatpak; return; fi
            native_version=$(apt_candidate "$package")
            flat_version=$(awk -F '\t' -v id="$id" '$1 == id && $3 == "stable" {print $2; exit}' \
                "$LOG_DIR/flathub-versions.tsv" 2>/dev/null)
            if [[ -n $native_version && $native_version != '(none)' && -n $flat_version ]] && \
                    /usr/bin/python3 "$SCRIPT_DIR/app-metadata.py" native-is-current "$native_version" "$flat_version"; then
                echo native
            else
                echo flatpak
            fi ;;
        *) return 2 ;;
    esac
}

install_selected_apps() {
    local policy package id name format
    run 'Refresh Flathub application metadata' \
        'Retry when Flathub is reachable.' \
        sudo -n flatpak update --system --appstream flathub
    run 'Read current Flathub versions for package selection' \
        'Unknown version comparisons use Flatpak; retry 1-first if Flathub is unreachable.' cache_flatpak_versions
    while IFS=$'\t' read -r policy package id name || [[ -n $policy ]]; do
        [[ -z $policy || $policy == \#* ]] && continue
        if [[ $policy != flatpak ]]; then
            prepare_app_source "$package" || continue
        fi
        format=$(choose_app_format "$policy" "$package" "$id") || {
            issue "Invalid install policy for $name: $policy"; continue;
        }
        note "$name: using $format (policy: $policy)."
        if [[ $format == native ]]; then
            install_native_app "$package" "$name" || continue
        elif flat_installed "$id"; then
            echo "Already installed: $name ($id)"
        else
            run "Install $name (Flatpak)" "Retry: sudo flatpak install --system flathub $id." \
                sudo -n flatpak install --system --noninteractive -y flathub "$id" || continue
        fi
        if [[ $format == native && $id != - ]] && flat_installed "$id"; then
            note "$name also has an older Flatpak installation. Its data was retained; use the native app. Remove the duplicate in GNOME Software after transferring any needed data."
        fi
    done < "$SCRIPT_DIR/apps.tsv"
}

selected_app_installed() {
    local policy=$1 package=$2 id=$3
    case "$policy" in
        native) pkg_installed "$package" ;;
        flatpak) flat_installed "$id" ;;
        auto) pkg_installed "$package" || flat_installed "$id" ;;
        *) return 1 ;;
    esac
}

snap_replacements_ready() {
    local policy package id name selected=0
    pkg_installed gnome-software || return 1
    while IFS=$'\t' read -r policy package id name || [[ -n $policy ]]; do
        [[ -z $policy || $policy == \#* ]] && continue
        case "$package" in
            vivaldi-stable|opera-gx-stable)
                selected=$((selected + 1))
                selected_app_installed "$policy" "$package" "$id" || return 1 ;;
        esac
    done < "$SCRIPT_DIR/apps.tsv"
    (( selected > 0 ))
}

verify_selected_apps() {
    local policy package id name
    while IFS=$'\t' read -r policy package id name || [[ -n $policy ]]; do
        [[ -z $policy || $policy == \#* ]] && continue
        if selected_app_installed "$policy" "$package" "$id"; then
            echo "PASS $name ($policy)"
        else
            issue "Missing $name ($policy). Rerun 1-first and review its log."
        fi
    done < "$SCRIPT_DIR/apps.tsv"
    if app_selected_pkg steam-launcher; then
        for package in libgl1:i386 libvulkan1:i386; do
            pkg_installed "$package" || issue "Missing Steam library $package. Rerun 1-first."
        done
    fi
}
