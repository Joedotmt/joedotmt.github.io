#!/usr/bin/env python3
"""Offline parsers used by app-install.sh; never runs downloaded code."""
import argparse
from html.parser import HTMLParser
from pathlib import Path
import re
import sys
from urllib.parse import urlparse


def release_number(version, debian=False):
    if debian:
        version = version.split(":", 1)[-1]
        version = re.split(r"(?:\+|~)(?:dfsg|ufsg|ds)", version, maxsplit=1)[0]
        version = version.split("-", 1)[0]
    # Do not mistake a release candidate or unknown string for stable.
    match = re.fullmatch(r"v?(\d+(?:\.\d+)*)(?:\+[^\s]+)?", version)
    if not match:
        return None
    numbers = tuple(int(part) for part in match[1].split("."))
    while len(numbers) > 1 and numbers[-1] == 0:
        numbers = numbers[:-1]
    return numbers


def native_is_current(native, flatpak):
    left, right = release_number(native, True), release_number(flatpak)
    return left is not None and right is not None and left >= right


def vivaldi_url(html):
    class Links(HTMLParser):
        def __init__(self):
            super().__init__()
            self.urls = set()

        def handle_starttag(self, tag, attrs):
            if tag != "a":
                return
            href = dict(attrs).get("href", "")
            parsed = urlparse(href)
            if (parsed.scheme == "https" and parsed.netloc == "downloads.vivaldi.com"
                    and re.fullmatch(r"/stable/vivaldi-stable_[0-9.]+-\d+_amd64\.deb", parsed.path)
                    and not parsed.query and not parsed.fragment):
                self.urls.add(href)
    parser = Links()
    parser.feed(html)
    if len(parser.urls) != 1:
        raise ValueError("Expected exactly one official stable amd64 Vivaldi DEB download")
    return parser.urls.pop()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    compare = sub.add_parser("native-is-current")
    compare.add_argument("native")
    compare.add_argument("flatpak")
    url = sub.add_parser("vivaldi-url")
    url.add_argument("html", type=Path)
    args = parser.parse_args()
    if args.command == "native-is-current":
        return 0 if native_is_current(args.native, args.flatpak) else 1
    try:
        print(vivaldi_url(args.html.read_text()))
    except (OSError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
