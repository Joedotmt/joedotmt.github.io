#!/usr/bin/env bash
# Ubuntu 26.10 / GNOME 51 / amd64. Run as the desktop user, WITHOUT sudo.
# No Unity components are installed. See APP-SOURCES.md for application choices.
set -uo pipefail
export LC_ALL=C.UTF-8
umask 077
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
STAGE=${1:-help}
DRY_RUN=0
if (( $# > 2 )) || { (( $# == 2 )) && [[ $2 != --dry-run ]]; }; then
    echo 'Usage: bash post-install.sh {system|desktop|verify} [--dry-run]' >&2
    exit 2
fi
[[ ${2:-} == --dry-run ]] && DRY_RUN=1

usage() {
    cat <<'EOF'
Ubuntu 26.10 / GNOME 51 post-install setup (no Unity)

Run in your friend's desktop account, WITHOUT sudo:
  ./1-first                          # packages, NVIDIA, applications, Snap removal
  [reboot; select "GNOME" in the login screen's gear menu]
  ./2-after-reboot-into-gnome          # extensions, dark appearance, titlebar buttons
  [log out, then log back into GNOME]
  ./3-last                           # checks and manual-action error log

Append --dry-run to any stage for a read-only plan; no sudo/network/log writes.
Every real run gets separate logs under ~/ubuntu-postinstall/logs/.
Stages may be rerun; completed app installs are retained. No automatic reboot.
Read assets/APP-SOURCES.md for application choices and update instructions.
EOF
}
case "$STAGE" in system|desktop|verify) ;; help|-h|--help) usage; exit 0 ;; *) usage >&2; exit 2 ;; esac
for asset in apps.tsv app-install.sh app-metadata.py extensions.json gnome-setup.py settings/aatws.json \
             extensions/advanced-alt-tab@G-dH.github.com.shell-extension.zip \
             extensions/arcmenu-interactions@local.shell-extension.zip; do
    [[ -r $SCRIPT_DIR/$asset ]] || { echo "Missing $asset. Extract the whole ZIP first." >&2; exit 2; }
done

plan() {
    echo "DRY RUN: $STAGE (no changes)"
    case "$STAGE" in
      system)
        echo 'Check Ubuntu 26.10, amd64, normal user; acquire sudo; back up package inventory.'
        echo 'APT update/upgrade; enable universe and multiverse; install GNOME, Flatpak and tools.'
        echo 'Use ubuntu-drivers install for the NVIDIA GPU; install intel-microcode.'
        echo 'Add system Flathub; install each of these applications independently:'
        while IFS=$'\t' read -r policy package id name || [[ -n $policy ]]; do
            [[ -z $policy || $policy == \#* ]] && continue
            printf '  %-8s %-28s APT=%s  Flatpak=%s\n' "$policy" "$name" "$package" "$id"
        done < "$SCRIPT_DIR/apps.tsv"
        echo 'native = upstream DEB/APT; auto = current APT or newer Flatpak; flatpak = preferred packaged build.'
        echo 'Enable i386 and matching OpenGL/Vulkan/NVIDIA libraries for native Steam when selected.'
        echo 'Use OBS PPA only if it publishes this Ubuntu codename; otherwise compare Ubuntu OBS with official Flatpak.'
        echo 'ChatGPT: official OpenAI amd64 DEB with its package-managed updates (26.10 requires a launch test).'
        echo 'VS Code: Microsoft APT repository; CurseForge: vendor .deb.'
        echo 'Epic Games Launcher: official Linux preview AppImage + desktop launcher.'
        echo 'Before Snap removal: require at least one selected browser, all selected browsers installed, and GNOME Software.'
        echo 'Back up /var/snap and ~/snap, remove snaps in dependency order, purge Snap packages.'
        echo 'Block snapd using an APT preference. Preserve user data backups. No autoremove.'
        echo 'Reboot manually, then choose the GNOME session.' ;;
      desktop)
        echo 'Require a live GNOME 51 session; back up GNOME settings.'
        echo 'Install only extensions declaring GNOME 51 support, from extensions.gnome.org.'
        echo 'Use a compatible distro AppIndicator/DING if the extension site has no compatible release.'
        echo 'Enable requested extensions for the next login; disable Ubuntu Dock if Dash to Panel installed.'
        echo 'Apply Adwaita-dark, dark preference, maximise/minimise buttons, bottom panel.'
        echo 'Select ArcMenu Windows 11 layout by reading its installed schema, not guessing a number.'
        echo 'Add No overview at start-up, bundled AATWS, and the bundled custom ArcMenu Interaction Fixes.'
        echo 'Restore this PC’s 108 AATWS settings and six GNOME switcher shortcuts before enabling it.'
        echo 'Log out and back in before verification.' ;;
      verify)
        echo 'Read-only checks: APT health, NVIDIA, Secure Boot, Flatpaks, native apps, Snap removal/pin.'
        echo 'Check GNOME session, dark settings, titlebar buttons and live extension states.'
        echo 'Record failed checks and screen-recording / Steam first-run tasks in the error log.' ;;
    esac
}
if (( DRY_RUN )); then plan; exit 0; fi

if (( EUID == 0 )); then
    echo 'Run this as the desktop user WITHOUT sudo. It requests sudo for system commands.' >&2
    exit 2
fi
BASE_DIR="$HOME/ubuntu-postinstall"
mkdir -p "$BASE_DIR" || exit 2
# One process at a time, including runs from other extracted copies.
exec 9>"$BASE_DIR/.lock"
flock -n 9 || { echo 'Another post-install run is already active.' >&2; exit 2; }
RUN_ID="$(date +%Y%m%d-%H%M%S)-$STAGE-$$"
LOG_DIR="$BASE_DIR/logs/$RUN_ID"
BACKUP_DIR="$BASE_DIR/backups/$RUN_ID"
mkdir -p "$LOG_DIR" "$BACKUP_DIR" || exit 2
ERROR_LOG="$LOG_DIR/error.log"
export POSTINSTALL_ERROR_LOG="$ERROR_LOG"
touch "$ERROR_LOG"
ln -sfn "$LOG_DIR" "$BASE_DIR/latest"
exec > >(tee -a "$LOG_DIR/install.log") 2>&1
ERRORS=0
STEP=0
issue() {
    ERRORS=$((ERRORS + 1))
    printf '\n[ACTION REQUIRED] %s\n' "$*" | tee -a "$ERROR_LOG"
}
note() { printf '\n[NOTE] %s\n' "$*" | tee -a "$LOG_DIR/next-steps.txt"; }
finish() {
    local rc=$?
    printf '\nRun finished (exit %s). Full log: %s\nError/manual-action log: %s\n' "$rc" "$LOG_DIR/install.log" "$ERROR_LOG"
}
trap finish EXIT
trap 'issue "Interrupted. APT may require: sudo dpkg --configure -a. Review install.log before rerunning this stage."; exit 130' INT TERM

# No global errexit: optional failures are logged, then independent work continues.
# Every mutating or important command is checked explicitly through run()/need().
run() {
    local label=$1 hint=$2 rc output
    shift 2
    STEP=$((STEP + 1))
    output="$LOG_DIR/step-$STEP.log"
    printf '\n[%s] %s\n' "$STAGE" "$label"
    printf 'Command:'; printf ' %q' "$@"; printf '\n'
    if [[ ${1:-} == sudo ]] && ! sudo -v; then
        issue "$label: sudo authentication failed. $hint"
        return 1
    fi
    "$@" 2>&1 | tee "$output"
    rc=${PIPESTATUS[0]}
    if (( rc != 0 )); then
        issue "$label failed (exit $rc). $hint"
        { printf 'Command:'; printf ' %q' "$@"; printf '\n'; cat "$output"; } >> "$ERROR_LOG"
    fi
    return "$rc"
}
need() { run "$@" || { issue 'Required prerequisite failed; stopping this stage. Fix the logged problem and rerun.'; exit 1; }; }
apt_do() {
    sudo -n env DEBIAN_FRONTEND=noninteractive apt-get \
      -o DPkg::Lock::Timeout=120 -o Dpkg::Options::=--force-confdef \
      -o Dpkg::Options::=--force-confold "$@"
}
# apt_do is a shell function; refresh sudo visibly before invoking run.
apt_step() {
    local label=$1; shift
    if ! sudo -v; then issue "$label: sudo authentication failed."; return 1; fi
    run "$label" 'Resolve the APT error shown below, then rerun system.' apt_do "$@"
}
pkg_installed() { [[ $(dpkg-query -W -f='${Status}' "$1" 2>/dev/null) == 'install ok installed' ]]; }
flat_installed() { flatpak info --system "$1" >/dev/null 2>&1; }
download() {
    local url=$1 dest=$2
    curl --fail --location --show-error --retry 3 --connect-timeout 20 --max-time 1800 \
      --proto '=https' --proto-redir '=https' --output "$dest.part" "$url" || return
    mv -f -- "$dest.part" "$dest"
}
check_os() {
    local ID='' VERSION_ID=''
    # shellcheck source=/dev/null
    source /etc/os-release
    [[ $ID == ubuntu && $VERSION_ID == 26.10 ]] || {
        issue "This script targets Ubuntu 26.10 only; found ${ID:-unknown} ${VERSION_ID:-unknown}."; exit 2;
    }
    [[ $(dpkg --print-architecture) == amd64 ]] || { issue 'This package selection requires amd64.'; exit 2; }
}
check_os
echo "Started $STAGE at $(date -Is). Logs: $LOG_DIR"

install_vscode() {
    # Repository is scoped to its own keyring; never use apt-key or trusted=yes.
    local key="$LOG_DIR/microsoft.asc" keyring="$LOG_DIR/microsoft.gpg" repo="$LOG_DIR/vscode.sources"
    run 'Download Microsoft repository key' 'See https://code.visualstudio.com/docs/setup/linux' \
      download 'https://packages.microsoft.com/keys/microsoft.asc' "$key" || return
    run 'Convert Microsoft keyring' 'Check that the downloaded key is valid OpenPGP.' \
      gpg --batch --yes --dearmor --output "$keyring" "$key" || return
    run 'Install scoped Microsoft keyring' 'Check /usr/share/keyrings permissions.' \
      sudo -n install -m 0644 "$keyring" /usr/share/keyrings/microsoft.gpg || return
    cat > "$repo" <<'EOF'
Types: deb
URIs: https://packages.microsoft.com/repos/code
Suites: stable
Components: main
Architectures: amd64
Signed-By: /usr/share/keyrings/microsoft.gpg
EOF
    # Fresh-install target: avoid adding a second source if VS Code already configured one.
    if ! rg_code_repo; then
        run 'Add VS Code APT repository' 'Check /etc/apt/sources.list.d/.' \
          sudo -n install -m 0644 "$repo" /etc/apt/sources.list.d/vscode.sources || return
    fi
    apt_step 'Refresh APT for VS Code' update || return
    apt_step 'Install Visual Studio Code' install -y code
}
rg_code_repo() {
    grep -rqsE '^[[:space:]]*(deb .*|URIs:[[:space:]]*)https://packages\.microsoft\.com/repos/code([/[:space:]]|$)' \
      /etc/apt/sources.list /etc/apt/sources.list.d 2>/dev/null
}
install_curseforge() {
    local deb="$LOG_DIR/curseforge.deb" package arch
    run 'Download CurseForge from its vendor' 'Download the Linux .deb at https://www.curseforge.com/download/app and install it manually.' \
      download 'https://curseforge.overwolf.com/downloads/curseforge-latest-linux.deb' "$deb" || return
    package=$(dpkg-deb -f "$deb" Package 2>/dev/null)
    arch=$(dpkg-deb -f "$deb" Architecture 2>/dev/null)
    if [[ $package != curseforge || $arch != amd64 ]]; then
        issue "CurseForge download is not the expected amd64 curseforge package. Inspect $deb; it was NOT installed."
        return 1
    fi
    # _apt can read the file in /var/tmp without making the private log directory public.
    local staged
    sudo -v || { issue 'Sudo authentication failed before staging CurseForge.'; return 1; }
    staged=$(sudo -n mktemp /var/tmp/curseforge-postinstall-XXXXXX.deb) || { issue 'Could not stage CurseForge package.'; return 1; }
    run 'Stage CurseForge package' 'Check free disk space.' sudo -n install -m 0644 "$deb" "$staged" || return
    apt_step 'Install CurseForge' install -y "$staged"
    local rc=$?
    run 'Remove temporary CurseForge installer' "Remove $staged manually." sudo -n rm -f -- "$staged"
    return "$rc"
}
install_epic() {
    local appdir="$HOME/Applications" path desktop
    path="$appdir/EpicGamesLauncher-x86_64.AppImage"
    mkdir -p "$appdir" "$HOME/.local/share/applications" || { issue 'Cannot create Epic application directories.'; return 1; }
    run 'Download official Epic Games Launcher Linux preview' 'Get the Linux AppImage at https://launcher.epicgames.com/.' \
      download 'https://launcher-public-service-prod06.ol.epicgames.com/launcher/api/installer/download/EpicGamesLauncher-x86_64.AppImage' "$LOG_DIR/Epic.AppImage" || return
    if [[ $(od -An -tx1 -N4 "$LOG_DIR/Epic.AppImage" | tr -d ' \n') != 7f454c46 ]]; then
        issue 'Epic download is not an ELF/AppImage executable; it was NOT installed.'; return 1
    fi
    run 'Install Epic AppImage for this user' 'Check ~/Applications permissions.' \
      install -m 0755 "$LOG_DIR/Epic.AppImage" "$path" || return
    # Escape desktop-entry Exec reserved characters, including unusual home paths.
    desktop="$HOME/.local/share/applications/epic-games-launcher.desktop"
    /usr/bin/python3 - "$path" "$desktop" <<'PY'
import sys
path = sys.argv[1]
escaped = ''.join(('\\' + c) if c in '\\"`$' else ('%%' if c == '%' else c) for c in path)
with open(sys.argv[2], 'w') as f:
    f.write('[Desktop Entry]\nType=Application\nName=Epic Games Launcher (Preview)\n'
            'Comment=Official Linux preview\nExec="' + escaped + '" %U\n'
            'Icon=applications-games\nTerminal=false\nCategories=Game;\n')
PY
    local rc=$?
    (( rc == 0 )) || { issue 'Could not write the Epic desktop launcher.'; return 1; }
    note 'Epic is the official Linux preview AppImage. Its launcher appears after the next login. Open it manually to sign in.'
}

# Application installation and verification share the same manifest and policy.
source "$SCRIPT_DIR/app-install.sh"

remove_snap() {
    # Browser/Software failure must never leave this account with no replacement.
    if ! snap_replacements_ready; then
        issue 'Snap removal deferred: select at least one supported browser (Vivaldi or Opera GX) in apps.tsv, install every selected browser and GNOME Software, then rerun system. Existing snaps remain available.'
        return 1
    fi
    local -a snap_data=() snaps=() remaining=() purge_packages=()
    local name round inventory
    [[ -d /var/snap ]] && snap_data+=(var/snap)
    [[ -d $HOME/snap ]] && snap_data+=("${HOME#/}/snap")
    if (( ${#snap_data[@]} )) && pkg_installed snapd; then
        run 'Back up Snap application data before removal' 'Close all Snap applications and retry. Snap removal is stopped if this backup fails.' \
          sudo -n tar --acls --xattrs -C / -czf "$BACKUP_DIR/snap-data.tar.gz" -- "${snap_data[@]}" || return
        run 'Give desktop user ownership of Snap backup' "Use sudo to access $BACKUP_DIR/snap-data.tar.gz." \
          sudo -n chown "$(id -u):$(id -g)" "$BACKUP_DIR/snap-data.tar.gz" || return
        note "Snap data saved to $BACKUP_DIR/snap-data.tar.gz. Browser profiles are backed up, not migrated."
    fi
    if pkg_installed snapd; then
        command -v snap >/dev/null || { issue 'snapd package exists but snap command is missing; repair it before removal.'; return 1; }
        # Capture before parsing, so a daemon/query error cannot masquerade as an empty list.
        run 'Read installed snaps' 'Check: sudo systemctl status snapd; snap list. No purge was attempted after a failed query.' \
          snap list || return
        inventory=$(snap list 2>"$LOG_DIR/snap-list-error.txt") || { issue 'Cannot query installed snaps; refusing to purge snapd.'; return 1; }
        printf '%s\n' "$inventory" > "$BACKUP_DIR/snaps-before.txt"
        mapfile -t snaps < <(printf '%s\n' "$inventory" | awk 'NR>1 {print $1}')
        # Apps/content/base/snapd can depend on one another. Retry deferred names
        # after removing their dependants. Only final failures need manual action.
        remaining=("${snaps[@]}")
        for round in {1..8}; do
            (( ${#remaining[@]} )) || break
            snaps=("${remaining[@]}"); remaining=()
            for name in "${snaps[@]}"; do
                echo "Removing snap $name (dependency pass $round)"
                sudo -v || { issue 'Sudo authentication failed during Snap removal; snapd was retained. Rerun system.'; return 1; }
                if ! sudo -n snap remove --purge "$name" >"$LOG_DIR/snap-$name.log" 2>&1; then
                    remaining+=("$name")
                fi
                cat "$LOG_DIR/snap-$name.log"
            done
            (( ${#remaining[@]} < ${#snaps[@]} )) || break
        done
        if (( ${#remaining[@]} )); then
            for name in "${remaining[@]}"; do
                issue "Could not remove snap $name. Inspect $LOG_DIR/snap-$name.log, resolve its dependency/mount issue, and rerun system. snapd was retained."
                cat "$LOG_DIR/snap-$name.log" >> "$ERROR_LOG"
            done
            return 1
        fi
    fi
    for name in snapd gnome-software-plugin-snap; do
        if pkg_installed "$name"; then purge_packages+=("$name"); fi
    done
    if (( ${#purge_packages[@]} )); then
        apt_step 'Purge Snap infrastructure' purge -y "${purge_packages[@]}" || return
    fi
    cat > "$LOG_DIR/no-snap.pref" <<'EOF'
Package: snapd
Pin: release *
Pin-Priority: -10
EOF
    run 'Block automatic snapd reinstallation' 'Check /etc/apt/preferences.d/ubuntu-postinstall-no-snap.pref.' \
      sudo -n install -m 0644 "$LOG_DIR/no-snap.pref" /etc/apt/preferences.d/ubuntu-postinstall-no-snap.pref || return
    # Leave backups/user data intact; do not use broad rm -rf or apt autoremove.
    note 'Snap packages and snapd removed; snapd blocked in APT. ~/snap and backup data, if present, are intentionally retained for recovery.'
}

system_stage() {
    need 'Authenticate administrator access' 'Use an account with sudo rights.' sudo -v
    run 'Save initial package inventory' 'Run dpkg-query -W manually if needed.' \
      bash -c 'dpkg-query -W > "$1"' _ "$BACKUP_DIR/packages-before.tsv"
    apt_step 'Update APT indexes' update || exit 1
    apt_step 'Install setup prerequisites' install -y ca-certificates curl gnupg python3 software-properties-common || exit 1
    run 'Enable Ubuntu universe' 'Enable universe in Software & Updates.' sudo -n add-apt-repository -y universe || return 1
    run 'Enable Ubuntu multiverse' 'Enable multiverse in Software & Updates.' sudo -n add-apt-repository -y multiverse || return 1
    if app_selected_pkg steam-launcher; then
        need 'Enable 32-bit packages for native Steam' 'Check dpkg architecture configuration.' \
            sudo -n dpkg --add-architecture i386
    fi
    apt_step 'Refresh enabled repositories' update || exit 1
    apt_step 'Upgrade installed packages' upgrade -y
    # Core desktop replacement is required before touching Snap.
    apt_step 'Install vanilla GNOME and Flatpak software manager' install -y \
      vanilla-gnome-desktop gnome-tweaks gnome-software gnome-software-plugin-flatpak \
      flatpak python3-gi gir1.2-glib-2.0 dconf-cli libglib2.0-bin \
      xdg-desktop-portal-gnome gnome-text-editor adwaita-icon-theme gnome-themes-extra || exit 1
    local package
    for package in gnome-shell-extension-appindicator gnome-shell-extension-desktop-icons-ng \
                   ubuntu-drivers-common intel-microcode mokutil pciutils git libfuse2t64 libx11-6; do
        apt_step "Install $package" install -y "$package"
    done
    if command -v ubuntu-drivers >/dev/null && lspci -n | grep -qi '10de:'; then
        run 'Install Ubuntu-recommended NVIDIA driver' 'Check ubuntu-drivers devices; use Ubuntu drivers, then reboot. Enrol a MOK at reboot if Secure Boot requests it.' \
          sudo -n ubuntu-drivers install
    else
        issue 'NVIDIA driver installation skipped: ubuntu-drivers or the NVIDIA GPU was not detected. Check lspci and ubuntu-drivers devices.'
    fi
    need 'Add system Flathub repository' 'Check internet access and https://flathub.org/en/setup/Ubuntu.' \
      sudo -n flatpak remote-add --system --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo
    install_selected_apps
    install_vscode
    install_curseforge
    install_epic
    remove_snap
    note 'SYSTEM STAGE FINISHED. Reboot. At the login screen select your user, then the gear menu > GNOME. Run the desktop stage from that account.'
    note 'If Secure Boot presents a MOK enrolment screen, complete it. Do not disable Secure Boot just to run this script.'
}

desktop_stage() {
    # NVIDIA Flatpak runtimes must match the driver loaded AFTER the reboot.
    run 'Refresh Flatpak apps and NVIDIA runtime after reboot' 'Retry: sudo flatpak update --system; then test OBS and Steam.' \
      sudo -n flatpak update --system --noninteractive -y
    need 'Install and configure compatible GNOME extensions and preferences' \
      'Review individual extension errors below. Rerun desktop after compatible releases appear. Log out/in before verify.' \
      /usr/bin/python3 "$SCRIPT_DIR/gnome-setup.py" setup --backup "$BACKUP_DIR" --state "$BASE_DIR/extensions-state.json"
    note 'DESKTOP STAGE FINISHED. Log out and back into GNOME to load extensions, then run verify.'
}

verify_stage() {
    local id name value audit
    audit=$(dpkg --audit 2>&1)
    if [[ -n $audit ]]; then issue "APT/dpkg needs attention: $audit. Check sudo dpkg --configure -a."; fi
    for name in vanilla-gnome-desktop gnome-tweaks gnome-software gnome-software-plugin-flatpak flatpak code curseforge intel-microcode libx11-6; do
        if pkg_installed "$name"; then echo "PASS package $name"; else issue "Missing package $name. Rerun system or install it with APT."; fi
    done
    verify_selected_apps
    if [[ -x $HOME/Applications/EpicGamesLauncher-x86_64.AppImage && -f $HOME/.local/share/applications/epic-games-launcher.desktop ]]; then
        echo 'PASS Epic AppImage and desktop launcher present'
    else issue 'Epic launcher missing. Rerun system or install the Linux preview from launcher.epicgames.com.'; fi
    if pkg_installed snapd || pkg_installed gnome-software-plugin-snap; then
        issue 'Snap infrastructure remains installed. Review the previous system-stage error.log and rerun system.'
    else echo 'PASS Snap infrastructure absent'; fi
    value=$(apt-cache policy snapd 2>/dev/null)
    if [[ $value != *'Candidate: (none)'* ]]; then issue 'snapd has an APT candidate. Review the no-snap APT preference.'; else echo 'PASS snapd has no APT candidate'; fi
    if command -v nvidia-smi >/dev/null; then
        run 'Check NVIDIA driver and GPU' 'Reboot; complete any MOK enrolment. Check ubuntu-drivers devices and journalctl -k -b for NVIDIA errors.' \
          nvidia-smi --query-gpu=name,driver_version --format=csv
    else issue 'nvidia-smi unavailable: NVIDIA driver is not ready. Rerun system, then reboot.'; fi
    if command -v mokutil >/dev/null; then run 'Read Secure Boot status' 'Check firmware Secure Boot settings.' mokutil --sb-state; fi
    if command -v flatpak >/dev/null; then
        echo 'Flatpak active GL drivers (read-only):'
        flatpak --gl-drivers
        echo 'Installed NVIDIA Flatpak runtime extensions (if required):'
        flatpak list --system --runtime --columns=application | grep -i nvidia || true
    fi
    run 'Verify live desktop settings and extensions' 'Review extension-specific actions below. Run desktop again if needed, then log out/in.' \
      /usr/bin/python3 "$SCRIPT_DIR/gnome-setup.py" verify --backup "$BACKUP_DIR" --state "$BASE_DIR/extensions-state.json"
    # Human-only checks belong in the same requested log, clearly distinct from failures.
    cat >> "$ERROR_LOG" <<'EOF'

[MANUAL CHECK] Open ChatGPT and sign in. The official Linux preview currently lists Ubuntu 24.04/26.04; verify it opens on 26.10.
[MANUAL CHECK] Launch your selected browsers and applications; complete account sign-ins. In Steam > Settings > Compatibility enable Steam Play/Proton for other titles if wanted. Game compatibility varies.
[MANUAL CHECK] Test OBS and GPU Screen Recorder on GNOME Wayland after approving the screen-sharing portal. Try H.264/NVENC on the RTX 3060 Ti. Installation checks cannot prove audio/video capture works.
[MANUAL CHECK] Open Epic Games Launcher (Preview) and CurseForge once. If an AppImage fails with a FUSE or AppArmor/user-namespace error, inspect the terminal output and vendor instructions. Do not globally disable AppArmor or pass --no-sandbox.
[MANUAL CHECK] After each NVIDIA driver upgrade/reboot run: sudo flatpak update --system for remaining Flatpak apps. Native Steam also needs the matching 32-bit NVIDIA library; rerun 1-first if it fails after a driver change.
[MANUAL CHECK] After logging into GNOME, confirm the desktop appears without the Overview and try Alt+Tab / Super+Tab. The verifier compares all 108 saved AATWS settings and six GNOME switcher shortcuts.
[MANUAL CHECK] Test ArcMenu Interaction Fixes: opening ArcMenu should leave normal/maximised windows alone, instantly minimise only the focused fullscreen game, and dismiss the menu with one click on a window, desktop or panel control. See assets/extensions/arcmenu-interactions@local.shell-extension.zip > README.md for the complete checks and GNOME 51 limits.
EOF
    note 'VERIFICATION FINISHED. Read this run’s error.log, including the manual functional checks. Earlier run logs are retained; successful reruns do not erase historical errors.'
}

case "$STAGE" in system) system_stage ;; desktop) desktop_stage ;; verify) verify_stage ;; esac
STAGE_RC=$?
if (( STAGE_RC != 0 || ERRORS > 0 )); then
    echo 'One or more steps need attention; see error.log.'
    exit 1
fi
echo 'Automated steps completed. See next-steps.txt and any manual checks in error.log.'
